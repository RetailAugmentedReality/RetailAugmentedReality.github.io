package com.wikitude.samples;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import com.wikitude.sdksamples.R;

public class Splash extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.splash_screen);
		setContentView(R.layout.splash_screen);
		Thread splashtimer = new Thread(){
			public void run(){
				try {
					sleep(1000);
				}
				catch(InterruptedException e){
				  e.printStackTrace();	
				}
				finally{
					Intent startMain = new Intent(Splash.this,QuickResponse.class);
					startActivity(startMain);
				}
			}
			
		};
		splashtimer.start();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}
	
	
	

}
