/** Automatically generated file. DO NOT MODIFY */
package com.wikitude.sdksamples;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}