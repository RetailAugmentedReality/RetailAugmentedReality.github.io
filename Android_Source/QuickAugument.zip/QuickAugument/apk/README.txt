you can install this apk via commandline using
adb -d install -r [PATH-TO-THIS-APK]