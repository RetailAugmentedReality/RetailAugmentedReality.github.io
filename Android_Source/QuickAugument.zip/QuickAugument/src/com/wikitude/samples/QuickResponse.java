package com.wikitude.samples;



import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import android.widget.Toast;

import com.google.zxing.Result;
import com.google.zxing.client.android.CaptureActivity;

import com.wikitude.samples.utils.urllauncher.ARchitectUrlLauncherActivity;
import com.wikitude.sdksamples.R;

public class QuickResponse extends CaptureActivity{

	
	public String Encodedqrurl;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
	
	@Override 
    public void handleDecode(Result rawResult, Bitmap barcode) 
    {
    	

       Encodedqrurl = rawResult.getText();
        Toast.makeText(this.getApplicationContext(), "Scanned code " + Encodedqrurl, Toast.LENGTH_LONG).show();  
    	Intent callotherdecode = new Intent(QuickResponse.this,ARchitectUrlLauncherActivity.class);
    	callotherdecode.putExtra("needSent", Encodedqrurl);
    	startActivity(callotherdecode);
    }
}
